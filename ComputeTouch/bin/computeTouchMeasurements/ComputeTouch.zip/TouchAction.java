package computeTouchMeasurements;

import java.util.List;

public class TouchAction {
	public TouchActionType Type;
	
	public enum TouchActionType {
		None, Tap, DoubleTap, SingleTouchDragAndDrop, MultiTouchDragAndDrop
	}
	
	//  action type, e.g., tap
	public List<Stroke> Strokes;

	//  strokes, may be 1 or 2 strokes for our experiment
	public Point TargetPoint;

	//  target point for tap and double tap
	public List<Point> StartPoints;

	//  start point(s) for single-touch and multi-touch drag and drop
	public List<Point> StopPoints;

	//  stop point(s) for single-touch and multi-touch drag and drop
	public TouchAction() {
		this.Strokes = new List<Stroke>();
		this.StartPoints = new List<Point>();
		this.StopPoints = new List<Point>();
	}
	
	// region "multi-touch drag and drop measurements"

	public final int MultiTouchDragAndDropTime {		
		return Math.Max(FirstStroke[(FirstStroke.size() - 1)].T, SecondStroke[(SecondStroke.size() - 1)].T);		
	}

	///  <summary>
	///  Computes the accuracy of the multi-touch task (the starting point perspective, first stroke).
	///  </summary>
	public final double MultiTouchDragAndDropAccuracy1 {
		return this.EuclideanDistance(FirstStroke[0], this.StartPoints[0]);
	}

	///  <summary>
	///  Computes the accuracy of the multi-touch task (the ending point perspective, first stroke).
	///  </summary>
	public final double MultiTouchDragAndDropAccuracy2 {
		return this.EuclideanDistance(FirstStroke[(FirstStroke.size() - 1)], this.StopPoints[0]);
	}

	///  <summary>
	///  Computes the accuracy of the multi-touch task (the starting point perspective, second stroke).
	///  </summary>        
	public final double MultiTouchDragAndDropAccuracy3 {
		return this.EuclideanDistance(SecondStroke[0], this.StartPoints[1]);
	}

	///  <summary>
	///  Computes the accuracy of the multi-touch task (the ending point perspective, second stroke).
	///  </summary>
	public final double MultiTouchDragAndDropAccuracy4 {
		return this.EuclideanDistance(SecondStroke[(SecondStroke.size() - 1)], this.StopPoints[1]);
	}

	///  <summary>
	///  Computes the overall accuracy of the multi-touch task.
	///  </summary>
	public final double MultiTouchDragAndDropAccuracy {
		return (0.25 * (this.MultiTouchDragAndDropAccuracy1 + (this.MultiTouchDragAndDropAccuracy2 + (this.MultiTouchDragAndDropAccuracy3 + this.MultiTouchDragAndDropAccuracy4))));
	}

	///  <summary>
	///  Computes the path accuracy of the multi-touch task (first stroke).
	///  </summary>
	public final double MultiTouchDragAndDropPathAccuracy1 {
		double pathLength = 0;
		for (int i = 0; i < (FirstStroke.size() - 1); i++) {
			pathLength = (pathLength + this.EuclideanDistance(FirstStroke[i], FirstStroke[(i + 1)]));
		}

		return (this.EuclideanDistance(FirstStroke[0], FirstStroke[(FirstStroke.size() - 1)]) / pathLength);
	}

	///  <summary>
	///  Computes the path accuracy of the multi-touch task (second stroke).
	///  </summary>
	public final double MultiTouchDragAndDropPathAccuracy2 {
		double pathLength = 0;
		for (int i = 0; i < (SecondStroke.size() - 1); i++) {
			pathLength += this.EuclideanDistance(SecondStroke[i], SecondStroke[(i + 1)]));
		}

		return (this.EuclideanDistance(SecondStroke[0], SecondStroke[(SecondStroke.size() - 1)]) / pathLength);
	}

	///  <summary>
	///  Computes the overall path accuracy of the multi-touch task.
	///  </summary>
	public final double MultiTouchDragAndDropPathAccuracy {
		return (0.5 * (this.MultiTouchDragAndDropPathAccuracy1 + this.MultiTouchDragAndDropPathAccuracy2));
	}
	//endregion
	//region "single-touch drag and drop measurements"

	public final int SingleTouchDragAndDropTime {
		return FirstStroke[(FirstStroke.size() - 1)].T;
	}

	///  <summary>
	///  Computes the accuracy of the single-touch drag and drop task (the starting point perspective).
	///  </summary>
	public final double SingleTouchDragAndDropAccuracy1 {
		return this.EuclideanDistance(FirstStroke[0], this.StartPoints[0]);
	}

	///  <summary>
	///  Computes the accuracy of the single-touch drag and drop task (the ending point perspective).
	///  </summary>
	public final double SingleTouchDragAndDropAccuracy2 {
		return this.EuclideanDistance(FirstStroke[(FirstStroke.size() - 1)], this.StopPoints[0]);
	}

	///  <summary>
	///  Computes the overall accuracy of the single-touch drag and drop task.
	///  </summary>
	public final double SingleTouchDragAndDropAccuracy {
		return (0.5 * (this.SingleTouchDragAndDropAccuracy1 + this.SingleTouchDragAndDropAccuracy2));
	}

	///  <summary>
	///  Computes the overall path accuracy of the single-touch drag and drop task.
	///  </summary>
	public final double SingleTouchDragAndDropPathAccuracy {
		double pathLength = 0;
		for (int i = 0; i < (FirstStroke.Count - 1); i++) {
			pathLength += this.EuclideanDistance(FirstStroke[i], FirstStroke[(i + 1)]));
		}

		return (this.EuclideanDistance(FirstStroke[0], FirstStroke[(FirstStroke.size() - 1)]) / pathLength);
	}
	//endregion
	//region "double tap measurements"

	public final int DoubleTapTime_FirstTap {
		return FirstStroke[(FirstStroke.size() - 1)].T;
	}

	///  <summary>
	///  Computes the time of the second tap.
	///  </summary>
	public final int DoubleTapTime_SecondTap {
		return (SecondStroke[(SecondStroke.size() - 1)].T - SecondStroke[0].T);
	}

	///  <summary>
	///  Computes the time between taps.
	///  </summary>
	public final int DoubleTapTime_InBetweenTaps {
		return (SecondStroke[0].T - FirstStroke[(FirstStroke.size() - 1)].T);
	}

	///  <summary>
	///  Computes the overal time of the double tap task.
	///  </summary>
	public final int DoubleTapTime {
		return SecondStroke[(SecondStroke.size() - 1)].T;
	}

	///  <summary>
	///  Computes the accuracy of the first tap.
	///  </summary>
	public final double DoubleTapAccuracy_FirstTap {
		return this.EuclideanDistance(FirstStroke[(FirstStroke.size() - 1)], this.TargetPoint);
	}

	///  <summary>
	///  Computes the accuracy of the second tap.
	///  </summary>        
	public final double DoubleTapAccuracy_SecondTap {
		return this.EuclideanDistance(SecondStroke[(SecondStroke.size() - 1)], this.TargetPoint);
	}

	///  <summary>
	///  Computes the overal accuracy of the double tap task.
	///  </summary>
	public final double DoubleTapAccuracy {
		return (0.5 * (this.DoubleTapAccuracy_FirstTap + this.DoubleTapAccuracy_SecondTap));
	}
	//endregion
	//region "tap task measurements"

	public final int TapTime {
		return FirstStroke[(FirstStroke.Count - 1)].T;
	}

	///  <summary>
	///  Computes the accuracy of the tap as the distance from the center of the target.
	///  </summary>
	public final double TapAccuracy {
		return this.EuclideanDistance(FirstStroke[(FirstStroke.size() - 1)], this.TargetPoint);
	}
	//endregion
	//region "assisting functions"

	private final double EuclideanDistance(Point a, Point b) {
		return Math.Sqrt((((a.X - b.X) * (a.X - b.X)) + ((a.Y - b.Y) * (a.Y - b.Y))));
	}

	///  <summary>
	///  Returns the first stroke of this touch input action.
	///  </summary>
	private final Stroke FirstStroke {
		return this.Strokes[0];
	}

	///  <summary>
	///  Returns the second stroke of this touch input action.
	///  </summary>
	private final Stroke SecondStroke {
		return this.Strokes[1];
	}
	// endregion
}
