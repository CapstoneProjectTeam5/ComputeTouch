package computeTouchMeasurements;

import java.util.List;

public abstract class Stroke implements List<Point>
{
}